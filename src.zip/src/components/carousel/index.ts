"use client";

export { default as Carousel } from "./Carousel";
