import Footer1 from "./footer-1/Footer1";
import Footer2 from "./footer-2/Footer2";

export { Footer1, Footer2 };
