export const aboutLinks = [
  "Leaf page",
  "Leaf page",
];

export const customerCareLinks = [
  "Leaf page",
];

export const iconList = [
  { iconName: "facebook", url: "https://www.facebook.com/UILibOfficial" },
  { iconName: "twitter", url: "/" },
  { iconName: "youtube", url: "https://www.youtube.com/channel/UCsIyD-TSO1wQFz-n2Y4i3Rg" },
  { iconName: "google", url: "/" },
  { iconName: "instagram", url: "/" }
];
