export const customerCareLinks = [
  "Help Center",
  "Track Your Order",
  "Corporate & Bulk Purchasing",
  "Returns & Refunds"
];

export const iconList = ["facebook", "twitter", "youtube", "google", "instagram"];
