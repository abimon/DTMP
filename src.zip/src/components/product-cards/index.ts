import ProductCard1 from "./ProductCard1";
import ProductCard2 from "./ProductCard2";
import ProductCard3 from "./ProductCard3";
import ProductCard4 from "./ProductCard4";
import ProductCard5 from "./ProductCard5";
import ProductCard6 from "./ProductCard6";
import ProductCard7 from "./ProductCard7";
import ProductCard8 from "./ProductCard8";
import ProductCard9 from "./ProductCard9";
import ProductCard10 from "./ProductCard10";
import ProductCard11 from "./ProductCard11";
import ProductCard12 from "./ProductCard12";
import ProductCard13 from "./ProductCard13";
import ProductCard14 from "./ProductCard14";
import ProductCard15 from "./ProductCard15";
import ProductCard16 from "./ProductCard16";
import ProductCard17 from "./ProductCard17";
import ProductCard18 from "./ProductCard18";
import ProductCard19 from "./ProductCard19";

export {
  ProductCard1,
  ProductCard2,
  ProductCard3,
  ProductCard4,
  ProductCard5,
  ProductCard6,
  ProductCard7,
  ProductCard8,
  ProductCard9,
  ProductCard10,
  ProductCard11,
  ProductCard12,
  ProductCard13,
  ProductCard14,
  ProductCard15,
  ProductCard16,
  ProductCard17,
  ProductCard18,
  ProductCard19
};
