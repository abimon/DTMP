import AddNewPayment from "./AddNewPayment";
import BackToMethods from "./BackToMethods";
import MethodEditForm from "./MethodEditForm";
import PaymentMethodList from "./PaymentMethodList";

export { AddNewPayment, BackToMethods, MethodEditForm, PaymentMethodList };
