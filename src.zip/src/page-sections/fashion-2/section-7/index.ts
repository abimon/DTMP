export { default } from "./Section7";
