export { default } from "./Section2";
