export { default } from "./Section6";
