export { default } from "./Section10";
