export interface Banner {
  title: string;
  thumbnail: string;
  buttonText?: string;
  description?: string;
}
