interface Service {
  id: string;
  icon: string;
  title: string;
  description?: string;
}

export default Service;
