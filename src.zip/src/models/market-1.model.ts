interface MainCarouselItem {
  title?: string;
  imgUrl?: string;
  buttonLik?: string;
  buttonText?: string;
  description?: string;
}

export default MainCarouselItem;
