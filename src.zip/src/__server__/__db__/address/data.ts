export const addressList = [
  {
    id: "d27d0e28-c35e-4085-af1e-f9f1b1bd9c34",
    user: {
      id: "16c6edfe-3c30-47c0-ac12-118638865b0b",
      email: "Lonie52@gmail.com",
      phone: "980-937-8940",
      avatar:
        "https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/1089.jpg",
      password: "s55mt2Iqv5VGdFm",
      dateOfBirth: "1999-08-26T15:45:39.852Z",
      verified: true,
      name: {
        firstName: "Eleanora",
        lastName: "Donnelly",
      },
    },
    city: "New Zoietown",
    phone: "(213) 840-9416",
    street: "497 Erdman Passage",
    country: "Paraguay",
    title: "Office",
  },
  {
    id: "488cb38d-1614-45a6-b86d-bf69d6db2d48",
    user: {
      id: "7bb2ff89-82e5-4d86-8c22-aa6de7d81bc1",
      email: "Elise_Bayer78@yahoo.com",
      phone: "474.747.6369 x87034",
      avatar:
        "https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/568.jpg",
      password: "YVwTc4pzu81nO5D",
      dateOfBirth: "1943-11-04T02:51:46.743Z",
      verified: true,
      name: {
        firstName: "Dock",
        lastName: "Leannon",
      },
    },
    city: "Lake Jo",
    phone: "345-510-1406",
    street: "8000 Evans Brooks",
    country: "Mongolia",
    title: "Shop",
  },
  {
    id: "32a078f4-d3b1-4eea-bdda-c6dc01182e5c",
    user: {
      id: "7bb2ff89-82e5-4d86-8c22-aa6de7d81bc1",
      email: "Elise_Bayer78@yahoo.com",
      phone: "474.747.6369 x87034",
      avatar:
        "https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/568.jpg",
      password: "YVwTc4pzu81nO5D",
      dateOfBirth: "1943-11-04T02:51:46.743Z",
      verified: true,
      name: {
        firstName: "Dock",
        lastName: "Leannon",
      },
    },
    city: "Eribertoview",
    phone: "(932) 581-1393",
    street: "978 Elton Springs",
    country: "Uganda",
    title: "Garage",
  },
  {
    id: "a41a8078-6062-488d-a9ec-a3f37e9be6b6",
    user: {
      id: "cdecd2d1-cbbc-42f9-97be-992b32acc307",
      email: "Grayce_Gleichner@hotmail.com",
      phone: "1-317-756-1980 x799",
      avatar:
        "https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/341.jpg",
      password: "kR6OLkWUPYCFslU",
      dateOfBirth: "1999-10-25T20:29:55.240Z",
      verified: true,
      name: {
        firstName: "Mckayla",
        lastName: "Pacocha",
      },
    },
    city: "North Claudiamouth",
    phone: "201.292.9655 x140",
    street: "3899 Gutkowski Views",
    country: "Ghana",
    title: "Coffee House",
  },
  {
    id: "392f6957-c5e1-4f34-8f96-3b0739a03ea8",
    user: {
      id: "4391a36c-c4af-4eb9-b92f-35371a75e2c6",
      email: "Krystina.Balistreri81@gmail.com",
      phone: "268-621-1859 x7033",
      avatar:
        "https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/1113.jpg",
      password: "388o02RRbG9zUd5",
      dateOfBirth: "1995-05-19T17:44:39.199Z",
      verified: true,
      name: {
        firstName: "Monica",
        lastName: "Nolan",
      },
    },
    city: "Lolitaberg",
    phone: "445-946-3391",
    street: "789 Spencer Lock",
    country: "Tanzania",
    title: "Italian Restaurant",
  },
];
